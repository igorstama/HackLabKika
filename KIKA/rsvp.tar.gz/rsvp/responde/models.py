# -*- coding: utf-8 -*-


from django.db import models


class Event(models.Model):
	name = models.CharField(max_length=200)
	slug = models.CharField(max_length=25, unique=True)
	start_date = models.DateTimeField()
	end_date = models.DateTimeField()

	def __unicode__(self):
		return self.slug



ANSWERS = (("да", "ќе дојдам"), ("можеби", "можеби ќе дојдам"), ("не", "нема да дојдам"))

class Response(models.Model):
	event = models.ForeignKey(Event)
	person_name = models.CharField(max_length=150)
	person_email = models.CharField(max_length=100)
	answer = models.CharField(max_length=20, choices=ANSWERS)

	def __unicode__(self):
		return self.event.slug + " " + self.person_email + " " + self.answer



