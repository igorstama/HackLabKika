# -*- coding: utf-8 -*-


from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader, Context, RequestContext
from django.shortcuts import get_object_or_404, render_to_response

from rsvp.responde.models import Response, Event
from rsvp.responde.forms import ResponseForm



def index(request):
	e = Event.objects.all()
	return render_to_response("rsvp/events.html", {"events":e})



def show_event(request, event):
	e = get_object_or_404(Event, slug=event)
	if request.method == 'POST':
		form = ResponseForm(request.POST)
		r = form.save(commit=False)
		r.event = e

		try:
			answer = Response.objects.get(person_email=request.POST['person_email'], event=e)
			r.id = answer.id
		except:
			pass
		r.save()
		return render_to_response("rsvp/ok.html", {"e":e})
	
	else:
		form = ResponseForm()

	return render_to_response("rsvp/rsvp.html", {"e":e, "form":form})


