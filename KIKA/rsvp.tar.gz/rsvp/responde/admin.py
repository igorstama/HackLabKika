from django.contrib import admin
from rsvp.responde.models import Event, Response 

class EventAdmin(admin.ModelAdmin):
	pass

class ResponseAdmin(admin.ModelAdmin):
	pass


admin.site.register(Response, ResponseAdmin)
admin.site.register(Event, EventAdmin)
