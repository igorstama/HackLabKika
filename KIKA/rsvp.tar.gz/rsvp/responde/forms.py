from django import forms
from django.forms import ModelForm

from rsvp.responde.models import Response



class ResponseForm(ModelForm):
	class Meta:
		model = Response
		exclude = ['event']



