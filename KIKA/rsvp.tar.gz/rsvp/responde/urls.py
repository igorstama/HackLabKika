from django.conf.urls.defaults import *


urlpatterns = patterns('rsvp.responde.views',
	(r'^/$', 'index'),
	(r'^/(?P<event>\w+)/$', 'show_event'),
)
